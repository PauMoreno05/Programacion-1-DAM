package POO.Ejercicio5;

public class Prestamo {
    private int num_p;

    public Prestamo(int num_p){
        this.num_p = num_p;
    }

    public int getNum_p() {
        return num_p;
    }


    @Override
    public String toString() {
        return getNum_p() + " ";
    }
}
